detectron2.checkpoint 
=============================

.. automodule:: detectron2.checkpoint
    :members:
    :undoc-members:
    :show-inheritance:
